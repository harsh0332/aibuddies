# Motion & Animation Spec - AI Buddies

This document logs all the motion configurations, knobs, easing functions, and performance setups used to build the AI Buddies marketing landing page.

---

## 1. 3D Hero Particle Sphere Canvas
Located in: `src/components/sections/hero-canvas.tsx`

The Hero section renders a Fibonacci-distributed particle sphere that rotates, tilts, and repels particles near the cursor. The following Named Constants are exposed at the top of the component for easy tuning:

```typescript
export const PARTICLE_COUNT = 5000;    // Number of points distributed on the sphere
export const SPHERE_RADIUS = 2;        // 3D radius scale of the sphere
export const PARTICLE_COLOR = "#8b7fff"; // Signature purple-blue color hex
export const PARTICLE_SIZE = 0.025;    // Points size rendering attribute
export const REPEL_RADIUS = 1.2;       // Distance radius from mouse in local coordinate space to trigger repel
export const REPEL_FORCE = 0.6;        // Push multiplier away from the cursor
export const RETURN_LERP = 0.08;       // Return speed factor (linear interpolation) back to original grid positions
export const ROTATION_SPEED = 0.1;     // Y-axis Y rotation multiplier
```

### Interactions
- **Auto-Rotation**: Per frame Y-axis rotation increment: `delta * ROTATION_SPEED`.
- **Tilting**: Tilts points group toward the cursor using a dampening lerp (`lerp = 0.08`) based on normalised mouse pointer coordinates `(state.pointer.y * 0.25)` and `(-state.pointer.x * 0.25)`.
- **Mouse Repel**: Mouse screen coordinates are unprojected into world space at $Z=0$ and mapped into the points group's local coordinate space using `inverseMatrix`. Particles within `REPEL_RADIUS` are pushed outwards by `(1 - dist / REPEL_RADIUS) * REPEL_FORCE` with a slight random Z-jitter.

---

## 2. Custom Cursor
Located in: `src/components/ui/custom-cursor.tsx`

Tracks pointer movement and expands when hovering over interactive components.
- **Dott (Center)**: Tracks pointer position `1:1` using raw mouse events inside `requestAnimationFrame` to avoid React re-renders.
- **Ring (Outer)**: Trails behind the center dot using linear interpolation (lerp = `0.15`).
- **Interactive Hover**: When cursor hovers over elements `a, button, input, select, textarea, [role="button"], label`:
  - Ring scales up by `1.8x`
  - Changes border color to `#8b7fff`
  - Gains a soft CSS shadow glow: `box-shadow: 0 0 15px rgba(139,127,255,0.4)`
- **Mouse Down (Click)**: Ring scales down by `0.6x` and fills slightly.

---

## 3. Custom Bezier Easing
Standard transitions (reveals, scroll entrances, headers, text, and loaders) share a unified custom cubic-bezier ease for a premium, snappy spring-like transition instead of linear movements.

- **Entrance Easing**: `[0.16, 1, 0.3, 1]` (custom premium curve).
- **Loader Easing**: `[0.76, 0, 0.24, 1]`.

> [!NOTE]
> All Bezier easing arrays inside Framer Motion are explicitly cast as `as const` tuples in TypeScript to satisfy strict type declarations.

---

## 4. Accessibility & Performance Optimizations
- **Mobile Check**: Touch pointer coarse checking `window.matchMedia("(pointer: coarse)")` is executed on mount. 
  - If a touch-screen is detected, the custom cursor and R3F canvas are **disabled** completely.
  - Custom cursor falls back to native OS rendering.
  - Hero Canvas falls back to a clean radial gradient: `bg-[radial-gradient(circle_at_center,rgba(139,127,255,0.12),transparent_60%)]`.
- **Reduced Motion Check**: Listens to OS prefers-reduced-motion triggers: `window.matchMedia("(prefers-reduced-motion: reduce)")`.
  - If enabled, all 3D canvas rendering and custom cursors are automatically bypassed.

---

## Animation Enhancement Pass (v2)

### Hero globe upgrades (src/components/three/particle-field.tsx)
- **Multi-hue palette**: vertical gradient deep-blue (#0E5FB5) → primary (#2BA0DC) → bright cyan (#43C2D8), plus ~8% violet (#7C6FF0) accents and ~5% near-white sparks. Computed once at init — zero runtime cost.
- **Sparkle layer**: 220 oversized twinkle particles riding the morphing cloud (child of main Points, inherits all transforms). Opacity pulses via sin — knobs: `SPARKLE_COUNT`, size multiplier `2.4`.
- **Cursor swirl**: sweeping the mouse adds a decaying spin impulse to the globe (`swirl` accumulator, decay `0.94`, gain `2.0`). Hero-stage only.
- **Breathing brightness**: material opacity oscillates 0.86–0.98 (`0.92 + 0.06*sin`).

### New components
- `src/components/ui/tilt.tsx` — mouse-position 3D tilt + cyan glare spotlight (rAF lerp 0.12, max 6°). Applied to Portfolio + WhyUs cards. Off on touch/reduced-motion.
- `src/components/ui/ambient.tsx` — floating blurred gradient orbs (CSS `drift-a`/`drift-b`, 14s/18s). Added to Problem, Process (flipped), Solutions. Hidden below `md` + reduced-motion.

### CSS utilities (globals.css)
- `.btn-shine` — light sweep across primary CTAs on hover (hero, navbar, why-us, final CTA).
- `.aurora-bg` — slow panning multi-blue gradient inside the Final CTA panel (16s).
- `.marquee-mask`/`.marquee-track` — infinite client-logo marquee in TrustBar (30s, pause on hover, edge fade mask; static wrap on touch/reduced-motion).
- `.float-orb` + drift keyframes; `.underline-draw` helper.
- Services carousel cards now glow on hover (`box-shadow`, no transform conflict).
- Cursor gained a soft trailing glow halo (slow lerp 0.10, 160px radial, z-997).
- FAQ + Contact sections gained a masked grid-texture layer.
- Heading underline draw-in (framer width reveal) under Portfolio + WhyUs h2.

### Guardrails
All new effects are transform/opacity/box-shadow only; every decorative animation is disabled under `(pointer: coarse)` and `(prefers-reduced-motion: reduce)`; orbs hidden on mobile; marquee degrades to a static wrapped row.
