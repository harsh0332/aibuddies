/* =============================================================================
   STATIC VARIANT — mobile & prefers-reduced-motion fallback. No WebGL, no rAF.
   Same design tokens as the motion variant (COL + TYPE from window).
   ============================================================================= */
const { COL: SCOL, SERVICES: SSERVICES, POWERED: SPOWERED, StaticIcon, TYPE: STYPE } = window;

function StaticVariant() {
  return (
    <div className="relative z-10" style={{ background: SCOL.bg }}>
      {/* HERO */}
      <section data-screen-label="Hero" className="relative overflow-hidden" style={{ padding: '28px 24px 72px' }}>
        <div className="pointer-events-none absolute inset-0"
          style={{ background: 'radial-gradient(70% 50% at 50% 18%, rgba(43,160,220,0.22), rgba(14,95,181,0.05) 45%, transparent 70%)' }} />
        <nav className="relative flex items-center justify-between">
          <div className="flex items-center gap-3" style={{ ...STYPE.component, color: SCOL.text }}>
            <span className="grid place-items-center h-7 w-7" style={{ borderRadius: 8, background: SCOL.accent, boxShadow: SCOL.glow }}>
              <span className="block h-2.5 w-2.5 rounded-full bg-black/85" />
            </span>
            AI Buddies
          </div>
          <a href="#" style={{ ...STYPE.labelSm, fontWeight: 600, color: SCOL.text, padding: '8px 16px', borderRadius: 40, border: `1px solid ${SCOL.primary}`, boxShadow: SCOL.glow }}>Book a Call</a>
        </nav>

        {/* glowing orb stand-in */}
        <div className="relative mx-auto h-44 w-44" style={{ marginTop: 48 }}>
          <div className="absolute inset-0 rounded-full" style={{ background: `radial-gradient(circle at 38% 32%, ${SCOL.accent}, ${SCOL.deep} 70%)`, boxShadow: `0 0 70px -6px ${SCOL.accent}` }} />
          <div className="absolute inset-0 rounded-full" style={{ background: 'radial-gradient(circle at 65% 70%, rgba(255,255,255,0.18), transparent 50%)' }} />
        </div>

        <h1 className="relative text-center" style={{ fontSize: 40, lineHeight: '44px', fontWeight: 300, letterSpacing: '-0.02em', color: SCOL.text, marginTop: 48 }}>
          We build <span style={{ color: SCOL.accent, fontStyle: 'italic', fontWeight: 700 }}>AI systems</span> that run your business.
        </h1>
        <p className="relative text-center" style={{ ...STYPE.bodyLg, color: SCOL.text60, marginTop: 20 }}>We help businesses stop doing things manually and start running on AI.</p>
        <a href="#" className="relative mx-auto flex w-fit items-center gap-2" style={{ ...STYPE.labelSm, fontWeight: 600, marginTop: 28, color: '#021018', padding: '12px 24px', borderRadius: 40, background: SCOL.accent, boxShadow: SCOL.glow }}>
          Book a Free Call
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </a>

        <div className="relative grid grid-cols-3 text-center" style={{ marginTop: 48, gap: 16 }}>
          {[['6+', 'Businesses Automated'], ['5', 'AI Systems'], ['24/7', 'Always-On']].map(([k, v]) => (
            <div key={v}>
              <div style={{ ...STYPE.cardTitle, color: SCOL.text }}>{k}</div>
              <div style={{ ...STYPE.labelSm, color: SCOL.text60, marginTop: 8 }}>{v}</div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES — stacked cards */}
      <section data-screen-label="Services" style={{ padding: '0 24px 96px' }}>
        <div style={{ ...STYPE.labelXs, fontWeight: 600, letterSpacing: '0.3em', textTransform: 'uppercase', color: SCOL.accent }}>What We Build</div>
        <h2 className="tracking-tight" style={{ ...STYPE.section, color: SCOL.text, marginTop: 12 }}>AI Automations &amp; Skills</h2>

        <div className="flex flex-col" style={{ marginTop: 32, gap: 16 }}>
          {SSERVICES.map(s => (
            <div key={s.n} style={{ borderRadius: 24, padding: 24, border: `1px solid rgba(43,160,220,0.2)`, background: 'linear-gradient(180deg, rgba(8,12,18,0.8), rgba(2,2,2,0.7))' }}>
              <div className="flex items-center justify-between">
                <span className="tabular-nums" style={{ color: SCOL.accent, fontSize: 40, fontWeight: 700, lineHeight: 1 }}>{s.n}</span>
                <StaticIcon shape={s.shape} />
              </div>
              <h3 className="tracking-tight" style={{ ...STYPE.cardTitle, color: SCOL.white, marginTop: 16 }}>{s.title}</h3>
              <p style={{ ...STYPE.body, color: SCOL.text60, marginTop: 12 }}>{s.desc}</p>
              <div className="flex flex-wrap" style={{ marginTop: 16, gap: 8 }}>
                {s.sub.map(x => (<span key={x} style={{ ...STYPE.labelSm, color: SCOL.text, padding: '6px 14px', borderRadius: 40, background: 'rgba(67,194,216,0.10)', border: '1px solid rgba(67,194,216,0.22)' }}>{x}</span>))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center flex-wrap" style={{ marginTop: 32, gap: 8 }}>
          <span style={{ ...STYPE.labelXs, letterSpacing: '0.18em', textTransform: 'uppercase', color: SCOL.text40 }}>Powered by</span>
          {SPOWERED.map(p => (<span key={p} style={{ ...STYPE.labelSm, color: SCOL.text60, padding: '4px 12px', borderRadius: 40, border: '1px solid rgba(246,246,253,0.12)' }}>{p}</span>))}
        </div>
      </section>
    </div>
  );
}
window.StaticVariant = StaticVariant;
