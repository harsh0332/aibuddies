/* =============================================================================
   MOTION VARIANT — three.js particle field + sticky scroll choreography.
   Shared tokens/helpers come from window (see ai-buddies.jsx export block).
   ============================================================================= */
const {
  COL, SERVICES, POWERED, N, SHAPE_FNS,
  PARTICLE_COUNT, SPHERE_RADIUS, PARTICLE_SIZE, REPEL_RADIUS, REPEL_FORCE,
  RETURN_LERP, MORPH_LERP, ROTATION_SPEED, SERVICES_SCROLL_VH, CARD_STEP,
  ACTIVE_CARD_SCALE, LEFT_FRACTION,
  INTRO_GLOBE_DELAY, INTRO_GLOBE_MS, INTRO_SUPPORT_DELAY, WATERMARK_OPACITY, WATERMARK_PARALLAX,
  makeSphere, clamp, lerp, C_PART, C_ACC, C_WHITE,
  headlineWords, MOTION_CSS, TYPE,
} = window;

/* ----------------------------- service card -------------------------------- */
function ServiceCard({ data, register }) {
  return (
    <div ref={register} className="svc-card glass relative shrink-0 overflow-hidden"
      style={{ height: '64vh', maxHeight: 560, borderRadius: 24,
        border: '1px solid rgba(43,160,220,0.18)',
        background: 'linear-gradient(180deg, rgba(8,12,18,0.55), rgba(2,2,2,0.5))' }}>
      {/* active fill = brand primary graded to deep (keeps white text AA-legible) */}
      <div className="card-fill pointer-events-none absolute inset-0" style={{ opacity: 0, background: `linear-gradient(165deg, ${COL.primary} 0%, ${COL.deep} 78%)` }} />
      <div className="card-fill pointer-events-none absolute inset-x-0 top-0 h-[3px]"
        style={{ opacity: 0, background: COL.accent }} />

      <div className="relative h-full flex flex-col" style={{ padding: 40 }}>
        <div className="flex items-start justify-between">
          <span className="card-num tabular-nums" style={{ fontSize: 56, fontWeight: 700, lineHeight: 1, color: COL.accent }}>{data.n}</span>
          <span className="card-arrow grid place-items-center" style={{ height: 44, width: 44, borderRadius: 40, border: '1px solid rgba(67,194,216,0.35)' }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: COL.accent }}><path d="M7 17 17 7M9 7h8v8"/></svg>
          </span>
        </div>

        <h3 className="card-title mt-auto" style={{ ...TYPE.cardTitle, color: COL.white }}>{data.title}</h3>

        <div className="card-detail" style={{ opacity: 0 }}>
          <p style={{ ...TYPE.body, color: 'rgba(255,255,255,0.92)', marginTop: 16, maxWidth: '34ch' }}>{data.desc}</p>

          <div style={{ marginTop: 24 }}>
            <div className="card-eyebrow" style={{ ...TYPE.labelXs, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.7)' }}>Services</div>
            <div className="flex flex-wrap" style={{ gap: 8, marginTop: 12 }}>
              {data.sub.map(s => (
                <span key={s} style={{ ...TYPE.labelSm, color: COL.white, padding: '6px 14px', borderRadius: 40, background: 'rgba(255,255,255,0.14)', border: '1px solid rgba(255,255,255,0.28)' }}>{s}</span>
              ))}
            </div>
          </div>

          <div className="flex items-center" style={{ gap: 12, marginTop: 28 }}>
            <span style={{ ...TYPE.labelXs, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.6)' }}>Powered by</span>
            <div className="flex flex-wrap" style={{ gap: 8 }}>
              {POWERED.map(p => (<span key={p} style={{ ...TYPE.labelSm, color: 'rgba(255,255,255,0.85)' }}>{p}</span>))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- motion variant ------------------------------ */
function MotionVariant() {
  const canvasRef   = React.useRef(null);
  const servicesRef = React.useRef(null);
  const trackRef    = React.useRef(null);
  const cardRefs    = React.useRef([]);
  const counterRef  = React.useRef(null);
  const headlineRef = React.useRef(null);
  const watermarkRef = React.useRef(null);

  React.useEffect(() => {
    // play headline reveal + arm the supporting-content fade-up on mount
    const id = setTimeout(() => {
      headlineRef.current && headlineRef.current.classList.add('kinetic--anim');
      document.querySelectorAll('.intro-up').forEach(el => el.classList.add('intro-up--armed'));
    }, 80);
    // safety net: lock final visible state after the intro window (fires even when
    // the CSS animation timeline is throttled in a background tab)
    const done = setTimeout(() => {
      headlineRef.current && headlineRef.current.classList.add('kinetic--done');
      document.querySelectorAll('.intro-up').forEach(el => el.classList.add('intro-up--done'));
    }, INTRO_SUPPORT_DELAY + 1100);
    return () => { clearTimeout(id); clearTimeout(done); };
  }, []);

  React.useEffect(() => {
    let THREE = window.THREE, raf = 0, disposed = false;
    let renderer, scene, camera, points, geom, material, dotTex;
    const positions = new Float32Array(PARTICLE_COUNT * 3);
    const colors    = new Float32Array(PARTICLE_COUNT * 3);

    const SPHERE = makeSphere(PARTICLE_COUNT, SPHERE_RADIUS);
    const SHAPES = SERVICES.map(s => SHAPE_FNS[s.shape](PARTICLE_COUNT));

    const mouse = { nx: 0, ny: 0, active: false };
    const mouseWorld = { x: 0, y: 0 };
    let rotY = 0, tiltX = 0, tiltY = 0, trackX = 0, leftXWorld = 0;
    const introStart = performance.now();
    const easeOut = t => 1 - Math.pow(1 - t, 3);

    function dotTexture() {
      const c = document.createElement('canvas'); c.width = c.height = 64;
      const x = c.getContext('2d');
      const g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, 'rgba(255,255,255,1)');
      g.addColorStop(0.35, 'rgba(255,255,255,0.6)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      x.fillStyle = g; x.fillRect(0, 0, 64, 64);
      const t = new THREE.Texture(c); t.needsUpdate = true; return t;
    }
    function computeLeftX() {
      const halfH = Math.tan((camera.fov * Math.PI / 180) / 2) * camera.position.z;
      const halfW = halfH * camera.aspect;
      leftXWorld = -halfW * (1 - LEFT_FRACTION * 2);
    }

    function init() {
      THREE = window.THREE;
      renderer = new THREE.WebGLRenderer({ canvas: canvasRef.current, antialias: true, alpha: true, preserveDrawingBuffer: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(window.innerWidth, window.innerHeight);
      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 100);
      camera.position.z = 4.2;

      for (let i = 0; i < PARTICLE_COUNT; i++) {
        positions[i*3] = SPHERE[i*3]; positions[i*3+1] = SPHERE[i*3+1]; positions[i*3+2] = SPHERE[i*3+2];
        const m = Math.random();
        colors[i*3]   = lerp(C_PART[0], C_ACC[0], m) / 255;
        colors[i*3+1] = lerp(C_PART[1], C_ACC[1], m) / 255;
        colors[i*3+2] = lerp(C_PART[2], C_ACC[2], m) / 255;
      }
      geom = new THREE.BufferGeometry();
      geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geom.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      dotTex = dotTexture();
      material = new THREE.PointsMaterial({
        size: PARTICLE_SIZE, map: dotTex, vertexColors: true, transparent: true,
        opacity: 0.95, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true,
      });
      points = new THREE.Points(geom, material);
      scene.add(points);
      computeLeftX();
      loop();
    }

    function onResize() {
      if (!renderer) return;
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      computeLeftX();
    }
    function onMove(e) {
      mouse.nx = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.ny = -((e.clientY / window.innerHeight) * 2 - 1);
      mouse.active = true;
      const halfH = Math.tan((camera.fov * Math.PI / 180) / 2) * camera.position.z;
      mouseWorld.x = mouse.nx * halfH * camera.aspect;
      mouseWorld.y = mouse.ny * halfH;
    }

    function loop() {
      if (disposed) return;
      raf = requestAnimationFrame(loop);

      const sr = servicesRef.current.getBoundingClientRect();
      const vh = window.innerHeight;
      const scrollable = sr.height - vh;
      const sp = clamp(-sr.top / scrollable, 0, 1);
      const activeFloat = sp * (N - 1);
      const enter = clamp((vh - sr.top) / vh, 0, 1);
      const leave = clamp(sr.bottom / (vh * 0.6), 0, 1);
      const vis = enter < 1 ? 1 : Math.min(leave, 1);

      const i0 = Math.floor(activeFloat), i1 = Math.min(i0 + 1, N - 1), f = activeFloat - i0;
      const A = SHAPES[i0], B = SHAPES[i1];
      const damp = enter < 0.02 ? RETURN_LERP : MORPH_LERP;
      const pos = geom.attributes.position.array;
      const repelOn = enter < 0.85 && mouse.active;
      for (let i = 0; i < PARTICLE_COUNT; i++) {
        const k = i * 3;
        let tx = A[k]   + (B[k]   - A[k])   * f;
        let ty = A[k+1] + (B[k+1] - A[k+1]) * f;
        let tz = A[k+2] + (B[k+2] - A[k+2]) * f;
        tx = SPHERE[k]   + (tx - SPHERE[k])   * enter;
        ty = SPHERE[k+1] + (ty - SPHERE[k+1]) * enter;
        tz = SPHERE[k+2] + (tz - SPHERE[k+2]) * enter;
        if (repelOn) {
          const dx = pos[k] - mouseWorld.x, dy = pos[k+1] - mouseWorld.y;
          const d2 = dx*dx + dy*dy;
          if (d2 < REPEL_RADIUS * REPEL_RADIUS) {
            const d = Math.sqrt(d2) || 1e-4;
            const fp = (1 - d / REPEL_RADIUS) * REPEL_FORCE;
            tx += (dx / d) * fp; ty += (dy / d) * fp;
          }
        }
        pos[k]   += (tx - pos[k])   * damp;
        pos[k+1] += (ty - pos[k+1]) * damp;
        pos[k+2] += (tz - pos[k+2]) * damp;
      }
      geom.attributes.position.needsUpdate = true;

      rotY += ROTATION_SPEED * (1 - enter * 0.55);
      const tTiltX = mouse.ny * 0.26 * (1 - enter), tTiltY = mouse.nx * 0.4 * (1 - enter);
      tiltX += (tTiltX - tiltX) * 0.05; tiltY += (tTiltY - tiltY) * 0.05;
      points.rotation.set(tiltX, rotY + tiltY, 0);
      points.position.x += (lerp(0, leftXWorld, enter) - points.position.x) * 0.08;
      // one-shot globe intro: fade + scale in after the headline begins rising
      const introGlobe = easeOut(clamp((performance.now() - introStart - INTRO_GLOBE_DELAY) / INTRO_GLOBE_MS, 0, 1));
      points.scale.setScalar(lerp(0.9, 1, introGlobe));
      material.opacity = 0.95 * vis * introGlobe;
      renderer.render(scene, camera);

      // watermark parallax (subtle, hero only)
      if (watermarkRef.current) {
        const drift = -window.scrollY * WATERMARK_PARALLAX;
        watermarkRef.current.style.transform = `translateY(${drift}px)`;
      }

      // carousel + card states
      const focal = 56;
      const targetX = focal - activeFloat * CARD_STEP;
      trackX += (targetX - trackX) * 0.12;
      if (trackRef.current) trackRef.current.style.transform = `translate(${trackX}px, -50%)`;
      for (let i = 0; i < cardRefs.current.length; i++) {
        const card = cardRefs.current[i]; if (!card) continue;
        const t = clamp(1 - Math.abs(i - activeFloat), 0, 1);
        card.style.transform = `scale(${lerp(0.9, ACTIVE_CARD_SCALE, t)})`;
        card.style.opacity = lerp(0.4, 1, t);
        card.style.boxShadow = `0 0 10px 0 rgba(43,160,220,${(0.55 * t).toFixed(3)})`;
        card.style.borderColor = `rgba(43,160,220,${(0.18 + 0.62 * t).toFixed(3)})`;
        const fills = card.querySelectorAll('.card-fill');
        fills.forEach(el => el.style.opacity = t);
        const detail = card.querySelector('.card-detail');
        if (detail) detail.style.opacity = clamp((t - 0.45) / 0.55, 0, 1);
        const num = card.querySelector('.card-num');
        if (num) {
          const r = Math.round(lerp(C_PART[0], C_WHITE[0], t));
          const g = Math.round(lerp(C_PART[1], C_WHITE[1], t));
          const b = Math.round(lerp(C_PART[2], C_WHITE[2], t));
          num.style.color = `rgb(${r},${g},${b})`;
        }
        const arrow = card.querySelector('.card-arrow');
        if (arrow) {
          arrow.style.background = `rgba(255,255,255,${(0.16 * t).toFixed(3)})`;
          arrow.style.borderColor = t > 0.5 ? 'rgba(255,255,255,0.5)' : 'rgba(67,194,216,0.35)';
          const svg = arrow.querySelector('svg');
          if (svg) svg.style.color = t > 0.5 ? '#ffffff' : COL.accent;
        }
      }
      if (counterRef.current) {
        const cur = String(clamp(Math.round(activeFloat) + 1, 1, N)).padStart(2, '0');
        counterRef.current.textContent = `${cur} / 0${N}`;
      }
    }

    function start() { if (window.THREE) init(); else window.addEventListener('three-ready', init, { once: true }); }
    start();
    window.addEventListener('resize', onResize);
    window.addEventListener('mousemove', onMove);
    return () => {
      disposed = true; cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('three-ready', init);
      if (geom) geom.dispose();
      if (material) material.dispose();
      if (dotTex) dotTex.dispose();
      if (renderer) renderer.dispose();
    };
  }, []);

  return (
    <React.Fragment>
      <style>{MOTION_CSS}</style>
      <canvas ref={canvasRef} className="fixed inset-0 z-0" style={{ width: '100%', height: '100%' }} />

      <div className="relative z-10">
        {/* ----------------------------- HERO ----------------------------- */}
        <section id="hero" data-screen-label="Hero" className="relative h-screen w-full overflow-hidden">
          <div className="pointer-events-none absolute inset-0"
            style={{ background: 'radial-gradient(60% 55% at 50% 42%, rgba(43,160,220,0.20), rgba(14,95,181,0.06) 45%, transparent 72%)' }} />
          <div ref={watermarkRef} aria-hidden="true" className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden" style={{ willChange: 'transform' }}>
            <span className="select-none whitespace-nowrap"
              style={{ fontSize: 'clamp(72px, 16vw, 200px)', fontWeight: 700, lineHeight: 1, color: `rgba(246,246,253,${WATERMARK_OPACITY})`, letterSpacing: '0.01em' }}>AI&nbsp;BUDDIES</span>
          </div>

          <nav className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-7 md:px-12 py-6">
            <div className="flex items-center gap-3 tracking-tight" style={{ ...TYPE.component, color: COL.text }}>
              <span className="grid place-items-center h-7 w-7" style={{ borderRadius: 8, background: COL.accent, boxShadow: COL.glow }}>
                <span className="block h-2.5 w-2.5 rounded-full bg-black/85" />
              </span>
              AI Buddies
            </div>
            <div className="hidden md:flex items-center gap-10" style={{ ...TYPE.labelSm, color: COL.text60 }}>
              {['Work', 'Services', 'Process', 'Contact'].map(l => (<a key={l} href="#" className="nav-link transition-colors">{l}</a>))}
            </div>
            <a href="#" className="whitespace-nowrap transition-transform hover:scale-[1.03]"
              style={{ ...TYPE.labelSm, fontWeight: 600, color: COL.text, padding: '10px 20px', borderRadius: 40, border: `1px solid ${COL.primary}`, background: 'rgba(43,160,220,0.06)', boxShadow: COL.glow }}>Book a Free Call</a>
          </nav>

          <div className="absolute inset-0 z-10 flex items-center justify-center px-6">
            <h1 ref={headlineRef} className="kinetic text-center" data-kinetic
              style={{ ...TYPE.hero, color: COL.text }}>{headlineWords()}</h1>
          </div>

          <div className="intro-up absolute bottom-0 left-0 right-0 z-20 px-7 md:px-12 pb-9">
            <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
              <div className="max-w-md">
                <p style={{ ...TYPE.bodyLg, color: COL.text60 }}>We help businesses stop doing things manually and start running on AI.</p>
                <a href="#" className="inline-flex w-fit items-center gap-2 whitespace-nowrap transition-transform hover:scale-[1.03]"
                  style={{ ...TYPE.labelSm, fontWeight: 600, marginTop: 20, color: '#021018', padding: '12px 24px', borderRadius: 40, background: COL.accent, boxShadow: COL.glow }}>
                  Book a Free Call
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </a>
              </div>
              <div className="flex gap-12">
                {[['6+', 'Businesses Automated'], ['5', 'AI Systems Under One Roof'], ['24/7', 'Always-On']].map(([k, v]) => (
                  <div key={v} className="max-w-[150px]">
                    <div style={{ ...TYPE.cardTitle, color: COL.text }}>{k}</div>
                    <div style={{ ...TYPE.labelSm, color: COL.text60, marginTop: 8 }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* --------------------------- SERVICES --------------------------- */}
        <section ref={servicesRef} id="services" data-screen-label="Services" className="relative" style={{ height: `${SERVICES_SCROLL_VH}vh` }}>
          <div className="sticky top-0 h-screen w-full overflow-hidden">
            <div className="flex h-full w-full">
              <div className="relative w-[44%] md:w-1/2 h-full">
                <div className="absolute top-0 left-0 px-7 md:px-12" style={{ paddingTop: 120 }}>
                  <div style={{ ...TYPE.labelXs, fontWeight: 600, letterSpacing: '0.3em', textTransform: 'uppercase', color: COL.accent }}>What We Build</div>
                  <h2 className="tracking-tight" style={{ ...TYPE.section, color: COL.text, marginTop: 20 }}>AI Automations<br/>&amp; Skills</h2>
                  <p style={{ ...TYPE.bodyLg, color: COL.text60, marginTop: 24, maxWidth: '30ch' }}>Five systems, one stack. Scroll to explore what each buddy does.</p>
                </div>
                <div className="absolute left-7 md:left-12 flex items-center" style={{ bottom: 48, gap: 20 }}>
                  <div ref={counterRef} className="tabular-nums" style={{ ...TYPE.component, color: COL.text40, letterSpacing: '0.1em' }}>01 / 05</div>
                  <div className="flex items-center" style={{ gap: 8 }}>
                    {POWERED.map(p => (<span key={p} style={{ ...TYPE.labelSm, color: COL.text60, padding: '4px 12px', borderRadius: 40, border: '1px solid rgba(246,246,253,0.12)' }}>{p}</span>))}
                  </div>
                </div>
              </div>

              <div className="relative w-[56%] md:w-1/2 h-full overflow-hidden">
                <div ref={trackRef} className="absolute top-1/2 left-0 flex items-stretch" style={{ gap: '28px', willChange: 'transform' }}>
                  {SERVICES.map((s, i) => (<ServiceCard key={s.n} data={s} register={el => (cardRefs.current[i] = el)} />))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* spacer so the stage fades out over real content */}
        <section id="solutions" data-screen-label="After" className="relative px-7 md:px-12" style={{ background: COL.bg, paddingTop: 120, paddingBottom: 120 }}>
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="tracking-tight" style={{ ...TYPE.section, color: COL.text }}>One stack. Every buddy working at once.</h2>
            <p style={{ ...TYPE.bodyLg, color: COL.text60, marginTop: 20 }}>Chat, WhatsApp, voice, lead-qual and support — built on n8n and wired to your tools.</p>
          </div>
        </section>
      </div>
    </React.Fragment>
  );
}
window.MotionVariant = MotionVariant;

/* =============================================================================
   PORTING NOTE (Next.js + R3F target)
   1. Add "use client" at the top; merge ai-buddies.jsx + motion.jsx + static.jsx
      into one file and `import * as THREE from 'three'` (drop the window.THREE
      shim + the three-ready listener — call init() directly in the effect).
   2. This replaces the existing R3F particle file
      (src/components/three/particle-field.tsx) and the current Services section.
   3. Hero + Services render under ids #hero and #services with #solutions
      following in normal document flow (already wired below).
   4. Keep the canvas fixed at z-0 and all content at z-10 (as set on the
      <canvas> and the .relative.z-10 wrapper here).
   ============================================================================= */
