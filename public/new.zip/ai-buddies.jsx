/* =============================================================================
   AI BUDDIES — Hero + Services scroll experience  (single-file React component)

   Raw three.js (window.THREE in this preview; see PORTING NOTE at bottom for the
   `import * as THREE from 'three'` swap) driven by one requestAnimationFrame loop.
   All scroll choreography is CSS position:sticky + a rAF scroll-progress reader.

   CHANGED vs previous version (visual tokens only — logic untouched):
   • Recolored to the "Dark Cosmos" token system in AI Buddies blue: #020202 bg,
     primary #2BA0DC / accent #43C2D8 / tertiary #9FD9F2 / deep #0E5FB5, exact
     Plus Jakarta Sans type scale, 4px spacing grid, pill/2xl/3xl radii, single
     blue glow token, glass blur, 3px focus ring.
   • Re-skinned hero (two-weight 60px headline, 179.2px watermark, glow CTAs) and
     service cards (active = primary→deep filled panel + white text + blue glow,
     Services sub-list + Powered-by row); scroll/morph/carousel logic unchanged.

   ----------------------------- DESIGN TOKENS ---------------------------------
   "Antimatter AI Dark Cosmos", recolored to AI Buddies blue. All values live in
   COL (colors) and TYPE (type scale); CSS vars are mirrored in TOKEN_CSS so the
   whole component is token-driven — no ad-hoc hex or magic numbers.

   Colors:  bg #020202 · foreground #f6f6fd · white #ffffff
            primary #2BA0DC · accent #43C2D8 · tertiary #9FD9F2 · deep #0E5FB5
   Type (Plus Jakarta Sans): hero 60/300+700i · section 40/600 · subsection 36/600
            card-title 30/600 · component 20/600 · body-lg 18/400 · body 16/400
            label-sm 14/400 · label-xs 12/400 · watermark 179.2/700
   Spacing (4px grid): 4 6 8 12 16 20 24 28 32 40 48 72 80 120 240
   Radius:  sm4 md6 lg8 xl12 2xl16 3xl24 pill40
   Glow:    0 0 10px 0 rgba(43,160,220,0.55)  ·  glass blur 12 / 24
   Focus:   3px outline rgb(246,246,253), offset 0
   ----------------------------------------------------------------------------- */

const PARTICLE_COUNT    = 4000;
const SPHERE_RADIUS     = 1.4;
const PARTICLE_SIZE     = 0.045;
const REPEL_RADIUS      = 0.9;
const REPEL_FORCE       = 0.55;
const RETURN_LERP       = 0.10;
const MORPH_LERP        = 0.08;
const ROTATION_SPEED    = 0.0016;
const SERVICES_SCROLL_VH = 500;
const CARD_STEP         = 468;
const ACTIVE_CARD_SCALE = 1.0;
const LEFT_FRACTION     = 0.26;

/* ---- Hero intro sequence (one-shot on load; transform/opacity only) -------
   Order: headline lines rise (mask reveal) → globe fades+scales in → support
   content (subcopy / CTA / stats) fades up last. Disabled by reduced-motion. */
const INTRO_WORD_MS      = 820;   // per-word slide-up duration
const INTRO_LINE_STAGGER = 110;   // ms between headline lines
const INTRO_WORD_STAGGER = 36;    // ms between words within a line
const INTRO_GLOBE_DELAY  = 420;   // ms before the particle globe fades in
const INTRO_GLOBE_MS     = 900;   // globe fade + scale-in duration
const INTRO_SUPPORT_DELAY= 1000;  // ms before subcopy/CTA/stats fade up
const WATERMARK_OPACITY  = 0.05;  // faint ghosted brand watermark
const WATERMARK_PARALLAX = 0.06;  // px drift per px scrolled (desktop only)

/* ----------------------------- Color tokens -------------------------------- */
const COL = {
  bg:        '#020202',
  text:      '#f6f6fd',   // --color-foreground
  white:     '#ffffff',
  primary:   '#2BA0DC',   // brand — borders, active-card fill, interactive
  accent:    '#43C2D8',   // glow, ring highlights, particle color
  tertiary:  '#9FD9F2',   // lighter blue tint, secondary highlights
  deep:      '#0E5FB5',   // deep blue for gradients
  // aliases kept so engine/markup stay terse
  particle:  '#43C2D8',
  text60:    'rgba(246,246,253,0.6)',
  text40:    'rgba(246,246,253,0.4)',
  glow:      '0 0 10px 0 rgba(43,160,220,0.55)',
};

/* ----------------------------- Type scale (Plus Jakarta Sans) -------------- */
const TYPE = {
  hero:      { fontSize: '60px', fontWeight: 300, lineHeight: '60px', letterSpacing: '-0.02em' },
  section:   { fontSize: '40px', fontWeight: 600, lineHeight: '50px', letterSpacing: '-0.01em' },
  subsection:{ fontSize: '36px', fontWeight: 600, lineHeight: '39.6px' },
  cardTitle: { fontSize: '30px', fontWeight: 600, lineHeight: '30px', letterSpacing: '-0.01em' },
  component: { fontSize: '20px', fontWeight: 600, lineHeight: '28px' },
  bodyLg:    { fontSize: '18px', fontWeight: 400, lineHeight: '28px' },
  body:      { fontSize: '16px', fontWeight: 400, lineHeight: '24px' },
  labelSm:   { fontSize: '14px', fontWeight: 400, lineHeight: '20px' },
  labelXs:   { fontSize: '12px', fontWeight: 400, lineHeight: '16px' },
};

/* ----------------------------- Service content ----------------------------- */
const SERVICES = [
  { n: '01', title: 'AI Chatbots',
    desc: 'Intelligent, context-aware assistants that engage your visitors and automate customer interactions instantly.',
    sub: ['Website chat', 'Context memory', 'Instant replies'], shape: 'bubble' },
  { n: '02', title: 'WhatsApp Automation',
    desc: 'Automate broadcasts, reminders, and customer messaging pipelines directly on WhatsApp.',
    sub: ['Broadcasts', 'Reminders', 'Booking flows'], shape: 'hub' },
  { n: '03', title: 'Voice Agents',
    desc: 'AI voice systems that handle incoming queries and make outbound calls with natural human cadence.',
    sub: ['After-hours answering', 'Appointment booking', 'Outbound calls'], shape: 'waves' },
  { n: '04', title: 'Lead Qualification',
    desc: 'Identify and qualify prospects automatically, steering ready-to-buy clients to your sales team.',
    sub: ['Auto-scoring', 'Nurture', 'Routing'], shape: 'funnel' },
  { n: '05', title: 'AI Customer Support',
    desc: 'Resolve tickets, answer FAQs, and handle support 24/7 with zero human intervention.',
    sub: ['Ticket deflection', 'FAQ resolution', 'Human handoff'], shape: 'gear' },
];
const POWERED = ['n8n', 'WhatsApp API', 'LLMs', 'Webhooks'];
const N = SERVICES.length;

/* ============================================================================
   SHAPE GENERATORS — each returns a Float32Array(PARTICLE_COUNT*3).
   Indices map 1:1 across shapes so morphing is a per-particle position lerp.
   ========================================================================== */
const TAU = Math.PI * 2;
const rnd = (a, b) => a + Math.random() * (b - a);

function makeSphere(n, r) {
  const a = new Float32Array(n * 3);
  const phi = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < n; i++) {
    const y = 1 - (i / (n - 1)) * 2;
    const rad = Math.sqrt(Math.max(0, 1 - y * y));
    const th = phi * i;
    a[i*3]   = Math.cos(th) * rad * r;
    a[i*3+1] = y * r;
    a[i*3+2] = Math.sin(th) * rad * r;
  }
  return a;
}

// Rounded speech bubble (filled) with a tail at the lower-left.
function makeBubble(n) {
  const a = new Float32Array(n * 3);
  const W = 1.5, H = 1.05, cr = 0.42;          // half-width, half-height, corner radius
  const inRounded = (x, y) => {
    const ax = Math.abs(x), ay = Math.abs(y);
    if (ax <= W - cr || ay <= H - cr) return ax <= W && ay <= H;
    const dx = ax - (W - cr), dy = ay - (H - cr);
    return dx * dx + dy * dy <= cr * cr;
  };
  for (let i = 0; i < n; i++) {
    let x, y;
    if (i % 9 === 0) {                           // ~11% form the tail triangle
      const t = Math.random(), s = Math.random() * t;
      x = -0.55 + (s - t * 0.5) * 0.7;
      y = -H - t * 0.62 + 0.02;
    } else {
      do { x = rnd(-W, W); y = rnd(-H, H); } while (!inRounded(x, y));
    }
    a[i*3] = x; a[i*3+1] = y + 0.18; a[i*3+2] = rnd(-0.1, 0.1);
  }
  return a;
}

// Central node + radiating satellite nodes joined by link points.
function makeHub(n) {
  const a = new Float32Array(n * 3);
  const SAT = 6, R = 1.45;
  const sat = [];
  for (let s = 0; s < SAT; s++) {
    const ang = (s / SAT) * TAU + 0.3;
    sat.push([Math.cos(ang) * R, Math.sin(ang) * R]);
  }
  for (let i = 0; i < n; i++) {
    const r = i % 1;
    let x, y;
    const bucket = i % 5;
    if (bucket === 0) {                          // 20% center cluster
      const a2 = Math.random() * TAU, rr = Math.random() * 0.28;
      x = Math.cos(a2) * rr; y = Math.sin(a2) * rr;
    } else if (bucket === 1) {                   // 20% satellite clusters
      const s = sat[i % SAT];
      const a2 = Math.random() * TAU, rr = Math.random() * 0.2;
      x = s[0] + Math.cos(a2) * rr; y = s[1] + Math.sin(a2) * rr;
    } else {                                      // 60% along links
      const s = sat[i % SAT];
      const t = Math.random();
      x = s[0] * t + (Math.random() - 0.5) * 0.05;
      y = s[1] * t + (Math.random() - 0.5) * 0.05;
    }
    a[i*3] = x; a[i*3+1] = y; a[i*3+2] = rnd(-0.12, 0.12);
  }
  return a;
}

// Concentric ripple rings (sound waves) — flat, with gentle z undulation.
function makeWaves(n) {
  const a = new Float32Array(n * 3);
  const rings = [0.32, 0.62, 0.92, 1.22, 1.5];
  for (let i = 0; i < n; i++) {
    const ri = i % rings.length;
    const r = rings[ri] + (Math.random() - 0.5) * 0.04;
    const ang = Math.random() * TAU;
    a[i*3]   = Math.cos(ang) * r;
    a[i*3+1] = Math.sin(ang) * r;
    a[i*3+2] = Math.sin(ang * 6 + ri) * 0.12;
  }
  return a;
}

// Funnel: stacked rings whose radius shrinks toward the bottom (cone).
function makeFunnel(n) {
  const a = new Float32Array(n * 3);
  const top = 1.0, bot = -1.05, rTop = 1.45, rBot = 0.04;
  for (let i = 0; i < n; i++) {
    const t = Math.random();                     // 0=top wide, 1=bottom point
    const y = top + (bot - top) * t;
    const r = rTop + (rBot - rTop) * t;
    const ang = Math.random() * TAU;
    a[i*3]   = Math.cos(ang) * r;
    a[i*3+1] = y;
    a[i*3+2] = Math.sin(ang) * r;
  }
  return a;
}

// Gear / cog silhouette — toothed outer rim, body fill, inner hole.
function makeGear(n) {
  const a = new Float32Array(n * 3);
  const teeth = 9, rOut = 1.45, rIn = 1.12, rHole = 0.42;
  for (let i = 0; i < n; i++) {
    const bucket = i % 5;
    let x, y;
    if (bucket < 3) {                            // 60% toothed outline
      const ang = Math.random() * TAU;
      const tooth = Math.floor(((ang / TAU) * teeth) % teeth);
      const phase = ((ang / TAU) * teeth) % 1;
      const r = (phase < 0.5 ? rOut : rIn) + (Math.random() - 0.5) * 0.04;
      x = Math.cos(ang) * r; y = Math.sin(ang) * r;
    } else if (bucket === 3) {                   // 20% body fill ring
      const ang = Math.random() * TAU;
      const r = rnd(rHole + 0.08, rIn - 0.04);
      x = Math.cos(ang) * r; y = Math.sin(ang) * r;
    } else {                                      // 20% inner hole ring
      const ang = Math.random() * TAU;
      const r = rHole + (Math.random() - 0.5) * 0.05;
      x = Math.cos(ang) * r; y = Math.sin(ang) * r;
    }
    a[i*3] = x; a[i*3+1] = y; a[i*3+2] = rnd(-0.12, 0.12);
  }
  return a;
}

const SHAPE_FNS = { bubble: makeBubble, hub: makeHub, waves: makeWaves, funnel: makeFunnel, gear: makeGear };

/* ----------------------------- small helpers ------------------------------- */
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp  = (a, b, t) => a + (b - a) * t;
function hexRgb(h) { const m = h.replace('#',''); return [parseInt(m.slice(0,2),16), parseInt(m.slice(2,4),16), parseInt(m.slice(4,6),16)]; }
const C_PART = hexRgb(COL.accent), C_ACC = hexRgb(COL.primary), C_WHITE = [246,246,253];

function useReducedMotion() {
  const [reduced, setReduced] = React.useState(false);
  React.useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce), (hover: none), (pointer: coarse)');
    const update = () => setReduced(mq.matches || window.innerWidth < 820);
    update();
    mq.addEventListener('change', update);
    window.addEventListener('resize', update);
    return () => { mq.removeEventListener('change', update); window.removeEventListener('resize', update); };
  }, []);
  return reduced;
}

/* ============================================================================
   MOBILE / REDUCED-MOTION static icons
   ========================================================================== */
function StaticIcon({ shape }) {
  const s = { width: 40, height: 40, fill: 'none', stroke: COL.particle, strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (shape) {
    case 'bubble':  return <svg viewBox="0 0 24 24" {...s}><path d="M5 5h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H9l-4 4v-4H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/></svg>;
    case 'hub':     return <svg viewBox="0 0 24 24" {...s}><circle cx="12" cy="12" r="2.5"/><circle cx="4" cy="6" r="1.6"/><circle cx="20" cy="6" r="1.6"/><circle cx="4" cy="18" r="1.6"/><circle cx="20" cy="18" r="1.6"/><path d="M10 11 5 7M14 11l5-4M10 13l-5 4M14 13l5 4"/></svg>;
    case 'waves':   return <svg viewBox="0 0 24 24" {...s}><path d="M2 12h2M20 12h2"/><path d="M6 9v6M9 6v12M12 4v16M15 6v12M18 9v6"/></svg>;
    case 'funnel':  return <svg viewBox="0 0 24 24" {...s}><path d="M3 5h18l-7 8v6l-4 2v-8L3 5Z"/></svg>;
    case 'gear':    return <svg viewBox="0 0 24 24" {...s}><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/></svg>;
    default:        return null;
  }
}

/* ----------------------------- headline (kinetic) -------------------------- */
function headlineWords() {
  // Two masked lines; each word slides up from below (translateY 110% + blur)
  // into place, staggered line-by-line then word-by-word. Base = final state.
  const lines = [
    [ { t: 'We', a: false }, { t: 'build', a: false }, { t: 'AI', a: true }, { t: 'systems', a: true } ],
    [ { t: 'that', a: false }, { t: 'run', a: false }, { t: 'your', a: false }, { t: 'business.', a: false } ],
  ];
  let wi = 0;
  return lines.map((words, li) => (
    <span key={li} className="kw-line">
      {words.map((w, k) => {
        const delay = li * INTRO_LINE_STAGGER + k * INTRO_WORD_STAGGER;
        const el = (
          <span key={k} className="kw" style={{
            animationDelay: `${delay}ms`,
            color: w.a ? COL.accent : COL.text,
            fontStyle: w.a ? 'italic' : 'normal',
            fontWeight: w.a ? 700 : 300,
          }}>{w.t}{'\u00A0'}</span>
        );
        wi++;
        return el;
      })}
    </span>
  ));
}

/* ----------------------------- shared CSS ---------------------------------- */
const MOTION_CSS = `
.nav-link:hover { color: ${COL.text}; }
/* headline: line masks + per-word slide-up reveal */
.kinetic { display: flex; flex-direction: column; align-items: center; }
.kw-line { display: block; overflow: hidden; padding-bottom: 0.06em; white-space: nowrap; }
.kinetic .kw { display: inline-block; }
@media (prefers-reduced-motion: no-preference) {
  .kinetic.kinetic--anim .kw {
    opacity: 0;
    transform: translateY(110%);
    filter: blur(6px);
    animation: kwRise ${INTRO_WORD_MS}ms cubic-bezier(0.16,1,0.3,1) forwards;
  }
}
@keyframes kwRise {
  from { opacity: 0; transform: translateY(110%); filter: blur(6px); }
  60%  { opacity: 1; filter: blur(0); }
  to   { opacity: 1; transform: translateY(0); filter: blur(0); }
}
/* safety net: once the intro window elapses, lock the visible end-state even if
   the animation timeline was throttled (background tab / reduced perf) */
.kinetic--done .kw { opacity: 1 !important; transform: none !important; filter: none !important; animation: none !important; }
/* supporting content fades up after the headline + globe (JS arms .intro-up--armed) */
.intro-up { opacity: 1; }
@media (prefers-reduced-motion: no-preference) {
  .intro-up.intro-up--armed {
    opacity: 0;
    transform: translateY(18px);
    animation: introUp 700ms cubic-bezier(0.16,1,0.3,1) forwards;
    animation-delay: ${INTRO_SUPPORT_DELAY}ms;
  }
}
@keyframes introUp { to { opacity: 1; transform: translateY(0); } }
.intro-up.intro-up--done { opacity: 1 !important; transform: none !important; animation: none !important; }
.svc-card {
  width: 440px;
  transform-origin: center center;
  transition: opacity 0.25s ease;
  will-change: transform, opacity;
}
.card-fill { transition: opacity 0.3s ease; }
.card-detail { transition: opacity 0.3s ease; }
.glass { backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
a:focus-visible, button:focus-visible {
  outline: 3px solid ${COL.text};
  outline-offset: 0;
  border-radius: 40px;
}
.scroll-cue { animation: cue 2.1s ease-in-out infinite; }
@keyframes cue { 0%,100% { transform: translateY(0); opacity: .5;} 50% { transform: translateY(7px); opacity: 1; } }
`;

/* ============================================================================
   MAIN COMPONENT — picks motion vs static; sub-variants live in motion.jsx
   & static.jsx (loaded after this file, registered on window).
   ========================================================================== */
function AIBuddiesExperience() {
  const reduced = useReducedMotion();
  const Motion = window.MotionVariant, Static = window.StaticVariant;
  if (reduced) return Static ? <Static /> : null;
  return Motion ? <Motion /> : null;
}
window.AIBuddiesExperience = AIBuddiesExperience;

/* ----------------------------------------------------------------------------
   Export shared tokens/helpers for motion.jsx & static.jsx (separate scopes).
   -------------------------------------------------------------------------- */
Object.assign(window, {
  COL, SERVICES, POWERED, N, SHAPE_FNS,
  PARTICLE_COUNT, SPHERE_RADIUS, PARTICLE_SIZE, REPEL_RADIUS, REPEL_FORCE,
  RETURN_LERP, MORPH_LERP, ROTATION_SPEED, SERVICES_SCROLL_VH, CARD_STEP,
  ACTIVE_CARD_SCALE, LEFT_FRACTION,
  INTRO_WORD_MS, INTRO_LINE_STAGGER, INTRO_WORD_STAGGER,
  INTRO_GLOBE_DELAY, INTRO_GLOBE_MS, INTRO_SUPPORT_DELAY,
  WATERMARK_OPACITY, WATERMARK_PARALLAX,
  makeSphere, clamp, lerp, hexRgb, C_PART, C_ACC, C_WHITE,
  StaticIcon, headlineWords, MOTION_CSS, TYPE,
});
