/* ============================================================================
   AI BUDDIES — Animated Hero → Services scroll experience
   ----------------------------------------------------------------------------
   TWEAK KNOBS (edit these named consts to tune the whole experience):
     PARTICLE_COUNT      = 4000   // number of points in the cloud
     SPHERE_RADIUS       = 1.4    // hero sphere radius (world units, kept small)
     PARTICLE_SIZE       = 0.025  // point size (world units, sizeAttenuation)
     REPEL_RADIUS        = 1.2    // mouse influence radius (world units)
     REPEL_FORCE         = 0.6    // push strength when cursor is near
     RETURN_LERP         = 0.08   // how fast repelled points return / sphere settles
     MORPH_LERP          = 0.08   // how fast points lerp toward a morph target
     ROTATION_SPEED      = 0.08   // auto-rotation speed of the cloud (rad/sec)
     SERVICES_SCROLL_VH  = 300    // tall wrapper height in vh (sticky scroll length)
     HERO_SPHERE_OFFSET_X= 1.6    // push sphere to the RIGHT half (world units)

   Preview note: this file uses a global `THREE` (loaded via <script> in the
   harness). For the Next.js port see the PORTING NOTE at the bottom.
   ========================================================================== */

const THREE = window.THREE; // PORT: replace with  import * as THREE from 'three'
const { useRef, useEffect, useState } = React;

/* ---- TWEAK KNOBS ---------------------------------------------------------- */
const PARTICLE_COUNT       = 4000;
const SPHERE_RADIUS        = 1.4;
const PARTICLE_SIZE        = 0.04;   // bumped from 0.025 for crisp visibility
const REPEL_RADIUS         = 1.2;
const REPEL_FORCE          = 0.6;
const RETURN_LERP          = 0.08;
const MORPH_LERP           = 0.08;
const ROTATION_SPEED       = 0.08;
const SERVICES_SCROLL_VH   = 300;
const HERO_SPHERE_OFFSET_X = 1.6;

/* ---- DESIGN TOKENS -------------------------------------------------------- */
const TOKENS = {
  particle: '#43C2D8',
  accent:   '#2BA0DC',
  deep:     '#0E5FB5',
  base:     '#000000',
  raised:   '#050507',
  text:     '#f6f6fd',
  text2:    'rgba(246,246,253,0.6)',
};

/* ---- CONTENT (verbatim) --------------------------------------------------- */
const SERVICES = [
  { title: 'AI Chatbots',         desc: 'Intelligent, context-aware assistants that engage your visitors and automate customer interactions instantly.' },
  { title: 'WhatsApp Automation', desc: 'Automate broadcasts, reminders, and patient/customer messaging pipelines directly on WhatsApp.' },
  { title: 'Voice Agents',        desc: 'AI voice systems that handle incoming queries and perform outgoing calls with natural human cadence.' },
  { title: 'Lead Qualification',  desc: 'Identify and qualify prospects automatically, steering ready-to-buy clients to your sales representatives.' },
  { title: 'AI Customer Support', desc: 'Resolve tickets, answer FAQs, and handle customer service 24/7 with zero human intervention.' },
];

/* ============================================================================
   SHAPE GENERATORS  — each returns a Float32Array of length PARTICLE_COUNT*3.
   Equal length so any shape morphs into any other 1:1 by particle index.
   ========================================================================== */
function makeSphere(count) {
  const a = new Float32Array(count * 3);
  const phi = Math.PI * (3 - Math.sqrt(5)); // golden angle
  for (let i = 0; i < count; i++) {
    const y = 1 - (i / (count - 1)) * 2;
    const r = Math.sqrt(Math.max(0, 1 - y * y));
    const th = phi * i;
    a[i * 3]     = Math.cos(th) * r * SPHERE_RADIUS;
    a[i * 3 + 1] = y * SPHERE_RADIUS;
    a[i * 3 + 2] = Math.sin(th) * r * SPHERE_RADIUS;
  }
  return a;
}

function makeChatBubble(count) {
  const a = new Float32Array(count * 3);
  const W = 1.9, H = 1.25, rad = 0.55, yShift = 0.32;
  const tailN = Math.floor(count * 0.09);
  const bodyN = count - tailN;
  let i = 0;
  // rounded-rectangle body fill (rejection sample)
  while (i < bodyN) {
    const x = (Math.random() * 2 - 1) * W;
    const y = (Math.random() * 2 - 1) * H;
    const ax = Math.abs(x) - (W - rad);
    const ay = Math.abs(y) - (H - rad);
    let inside = (ax < 0 || ay < 0) ? true : (ax * ax + ay * ay) < rad * rad;
    if (inside) {
      a[i * 3]     = x;
      a[i * 3 + 1] = y + yShift;
      a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.12;
      i++;
    }
  }
  // little tail (bottom-left triangle)
  const A = [-0.45, -H + yShift], B = [-1.05, -H - 0.55 + yShift], C = [0.15, -H + yShift];
  for (let k = 0; k < tailN; k++) {
    let r1 = Math.random(), r2 = Math.random();
    if (r1 + r2 > 1) { r1 = 1 - r1; r2 = 1 - r2; }
    a[i * 3]     = A[0] + r1 * (B[0] - A[0]) + r2 * (C[0] - A[0]);
    a[i * 3 + 1] = A[1] + r1 * (B[1] - A[1]) + r2 * (C[1] - A[1]);
    a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.08;
    i++;
  }
  return a;
}

function makeNetworkHub(count) {
  const a = new Float32Array(count * 3);
  const nodes = 6, R = 1.55;
  const centers = [[0, 0]];
  for (let n = 0; n < nodes; n++) {
    const ang = (n / nodes) * Math.PI * 2 - Math.PI / 2;
    centers.push([Math.cos(ang) * R, Math.sin(ang) * R]);
  }
  const centerN = Math.floor(count * 0.16);
  const spokeN  = Math.floor(count * 0.50);
  const satN    = count - centerN - spokeN;
  let i = 0;
  for (let k = 0; k < centerN; k++) {
    const ang = Math.random() * Math.PI * 2, rr = Math.sqrt(Math.random()) * 0.30;
    a[i * 3] = Math.cos(ang) * rr; a[i * 3 + 1] = Math.sin(ang) * rr; a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.1; i++;
  }
  for (let k = 0; k < satN; k++) {
    const node = 1 + Math.floor(Math.random() * nodes);
    const ang = Math.random() * Math.PI * 2, rr = Math.sqrt(Math.random()) * 0.24;
    a[i * 3] = centers[node][0] + Math.cos(ang) * rr;
    a[i * 3 + 1] = centers[node][1] + Math.sin(ang) * rr;
    a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.1; i++;
  }
  for (let k = 0; k < spokeN; k++) {
    const node = 1 + Math.floor(Math.random() * nodes);
    const t = Math.random();
    a[i * 3]     = centers[node][0] * t + (Math.random() * 2 - 1) * 0.035;
    a[i * 3 + 1] = centers[node][1] * t + (Math.random() * 2 - 1) * 0.035;
    a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.05; i++;
  }
  return a;
}

function makeSoundWaves(count) {
  const a = new Float32Array(count * 3);
  const bars = 15, spread = 3.4;
  const heights = [];
  for (let b = 0; b < bars; b++) {
    const x = b / (bars - 1);
    heights[b] = 0.28 + Math.sin(x * Math.PI) * 1.35 * (0.55 + 0.45 * Math.abs(Math.sin(b * 1.7 + 0.6)));
  }
  for (let i = 0; i < count; i++) {
    const b = i % bars;
    const h = heights[b];
    a[i * 3]     = (b / (bars - 1) - 0.5) * spread + (Math.random() * 2 - 1) * 0.035;
    a[i * 3 + 1] = (Math.random() * 2 - 1) * h;
    a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.06;
  }
  return a;
}

function makeBullseye(count) {
  const a = new Float32Array(count * 3);
  const radii = [0.5, 1.0, 1.5, 1.95];
  const total = radii.reduce((s, r) => s + r, 0);
  const centerN = Math.floor(count * 0.08);
  let i = 0;
  for (let k = 0; k < centerN; k++) {
    const ang = Math.random() * Math.PI * 2, rr = Math.sqrt(Math.random()) * 0.18;
    a[i * 3] = Math.cos(ang) * rr; a[i * 3 + 1] = Math.sin(ang) * rr; a[i * 3 + 2] = 0; i++;
  }
  const remain = count - centerN;
  for (let r = 0; r < radii.length; r++) {
    const n = (r === radii.length - 1) ? count - i : Math.floor(remain * radii[r] / total);
    for (let k = 0; k < n && i < count; k++) {
      const ang = Math.random() * Math.PI * 2;
      const rr = radii[r] + (Math.random() * 2 - 1) * 0.05;
      a[i * 3] = Math.cos(ang) * rr; a[i * 3 + 1] = Math.sin(ang) * rr; a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.04; i++;
    }
  }
  while (i < count) { a[i * 3] = 0; a[i * 3 + 1] = 0; a[i * 3 + 2] = 0; i++; }
  return a;
}

function makeGear(count) {
  const a = new Float32Array(count * 3);
  const teeth = 9, outer = 1.7, toothH = 0.34, inner = 0.6;
  for (let i = 0; i < count; i++) {
    const ang = Math.random() * Math.PI * 2;
    const tooth = Math.sin(ang * teeth) > 0 ? toothH : 0;        // blocky teeth
    const outR = outer - toothH / 2 + tooth;
    const rr = inner + Math.sqrt(Math.random()) * (outR - inner); // annulus fill (hole in center)
    a[i * 3]     = Math.cos(ang) * rr;
    a[i * 3 + 1] = Math.sin(ang) * rr;
    a[i * 3 + 2] = (Math.random() * 2 - 1) * 0.08;
  }
  return a;
}

/* shapeIndex 0 = sphere (hero); 1..5 map to the five services in order */
function buildShapes() {
  return [
    makeSphere(PARTICLE_COUNT),
    makeChatBubble(PARTICLE_COUNT),
    makeNetworkHub(PARTICLE_COUNT),
    makeSoundWaves(PARTICLE_COUNT),
    makeBullseye(PARTICLE_COUNT),
    makeGear(PARTICLE_COUNT),
  ];
}

/* round soft particle sprite */
function makeSprite() {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d');
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0,   'rgba(255,255,255,1)');
  grad.addColorStop(0.3, 'rgba(255,255,255,0.85)');
  grad.addColorStop(1,   'rgba(255,255,255,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c);
  return t;
}

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const smoothstep = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };

/* ============================================================================
   COMPONENT
   ========================================================================== */
function AIBuddiesHero() {
  const canvasRef   = useRef(null);
  const heroRef     = useRef(null);
  const heroInner   = useRef(null);
  const wrapRef     = useRef(null);
  const mouse       = useRef({ x: 0, y: 0, active: false });
  const [activeStep, setActiveStep] = useState(0);
  const [isStatic, setIsStatic] = useState(false);

  // detect mobile / reduced-motion once
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const coarse  = window.matchMedia('(pointer: coarse)').matches;
    setIsStatic(reduced || coarse);
  }, []);

  /* ---- THREE.JS engine (skipped entirely when static) ------------------- */
  useEffect(() => {
    if (isStatic) return;
    const canvas = canvasRef.current;
    if (!canvas || !THREE) return;

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 100);
    camera.position.z = 5;

    const shapes = buildShapes();
    const current = new Float32Array(shapes[0]); // start as sphere
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(current, 3));

    const sprite = makeSprite();
    const mat = new THREE.PointsMaterial({
      size: PARTICLE_SIZE,
      map: sprite,
      color: new THREE.Color(TOKENS.particle),
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: false,
      sizeAttenuation: true,
    });
    const points = new THREE.Points(geo, mat);
    const group = new THREE.Group();
    group.add(points);
    group.position.x = HERO_SPHERE_OFFSET_X;
    scene.add(group);

    const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0); // z = 0
    const raycaster = new THREE.Raycaster();
    const mouseWorld = new THREE.Vector3();
    const ndc = new THREE.Vector2();

    let spinY = 0;
    let tiltX = 0, tiltY = 0;
    let curShape = 0;
    let raf = 0, last = performance.now();
    let disposed = false;

    function resize() {
      const w = window.innerWidth, h = window.innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    }
    resize();
    window.addEventListener('resize', resize);

    function onMove(e) {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.current.y = -((e.clientY / window.innerHeight) * 2 - 1);
      mouse.current.active = true;
    }
    function onLeave() { mouse.current.active = false; }
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerout', onLeave);

    function frame(now) {
      if (disposed) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      /* ---- scroll-driven state (read each frame, no scroll-jank) ---- */
      const heroRect = heroRef.current.getBoundingClientRect();
      const heroProg = clamp(-heroRect.top / heroRect.height, 0, 1);

      const wrapRect = wrapRef.current.getBoundingClientRect();
      const scrollable = Math.max(1, wrapRect.height - window.innerHeight);
      const svcProg = clamp(-wrapRect.top / scrollable, 0, 1);
      const stuck = wrapRect.top <= 0;
      const step = clamp(Math.floor(svcProg * 5), 0, 4);
      const shapeIndex = stuck ? step + 1 : 0;

      if (shapeIndex !== curShape) curShape = shapeIndex;

      // sync active card (state) only when it changes
      if (stuck) {
        setActiveStep(prev => (prev === step ? prev : step));
      }

      // hero content fade / lift as it scrolls away
      if (heroInner.current) {
        heroInner.current.style.opacity = String(clamp(1 - heroProg * 1.5, 0, 1));
        heroInner.current.style.transform = `translateY(${-heroProg * 40}px)`;
      }

      // canvas opacity: full through hero+services, fade out as services end
      const op = 1 - smoothstep(0.84, 1.0, svcProg);
      canvas.style.opacity = String(op);

      /* ---- group position: right half in hero, drift down on travel ---- */
      const targetGX = HERO_SPHERE_OFFSET_X;
      const targetGY = stuck ? 0 : -heroProg * 1.4;
      group.position.x += (targetGX - group.position.x) * (1 - Math.pow(1 - 0.1, dt * 60));
      group.position.y += (targetGY - group.position.y) * (1 - Math.pow(1 - 0.1, dt * 60));

      /* ---- mouse world point (for repel) ---- */
      ndc.set(mouse.current.x, mouse.current.y);
      raycaster.setFromCamera(ndc, camera);
      raycaster.ray.intersectPlane(plane, mouseWorld);

      /* ---- rotation: auto-spin + cursor tilt ---- */
      spinY += ROTATION_SPEED * dt;
      const wantTiltX = mouse.current.active ? mouse.current.y * 0.22 : 0;
      const wantTiltY = mouse.current.active ? mouse.current.x * 0.22 : 0;
      tiltX += (wantTiltX - tiltX) * (1 - Math.pow(1 - 0.06, dt * 60));
      tiltY += (wantTiltY - tiltY) * (1 - Math.pow(1 - 0.06, dt * 60));
      group.rotation.y = spinY + tiltY;
      group.rotation.x = tiltX;

      /* ---- per-particle: lerp toward target, apply hero repel ---- */
      const target = shapes[curShape];
      const isHero = curShape === 0;
      const rate = isHero ? RETURN_LERP : MORPH_LERP;
      const f = 1 - Math.pow(1 - rate, dt * 60);
      const gx = group.position.x, gy = group.position.y;

      for (let i = 0; i < PARTICLE_COUNT; i++) {
        const ix = i * 3, iy = ix + 1, iz = ix + 2;
        // morph / return lerp
        current[ix] += (target[ix] - current[ix]) * f;
        current[iy] += (target[iy] - current[iy]) * f;
        current[iz] += (target[iz] - current[iz]) * f;

        // mouse repel only in hero (sphere reacts, then lerps back)
        if (isHero && mouse.current.active) {
          const wx = current[ix] + gx, wy = current[iy] + gy, wz = current[iz];
          const dx = wx - mouseWorld.x, dy = wy - mouseWorld.y, dz = wz - mouseWorld.z;
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (dist < REPEL_RADIUS && dist > 0.0001) {
            const push = (1 - dist / REPEL_RADIUS) * REPEL_FORCE;
            current[ix] += (dx / dist) * push;
            current[iy] += (dy / dist) * push;
            current[iz] += (dz / dist) * push;
          }
        }
      }
      geo.attributes.position.needsUpdate = true;

      renderer.render(scene, camera);
      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerout', onLeave);
      geo.dispose();
      mat.dispose();
      sprite.dispose();
      renderer.dispose();
    };
  }, [isStatic]);

  /* ======================================================================
     RENDER
     ====================================================================== */
  const rootStyle = {
    '--particle': TOKENS.particle, '--accent': TOKENS.accent, '--deep': TOKENS.deep,
    '--base': TOKENS.base, '--raised': TOKENS.raised, '--text': TOKENS.text, '--text2': TOKENS.text2,
    background: TOKENS.base, color: TOKENS.text,
    fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif",
  };

  return (
    <div style={rootStyle} className="relative w-full overflow-x-hidden antialiased">
      {/* radial brand glow behind everything */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          background:
            'radial-gradient(60% 55% at 72% 42%, rgba(43,160,220,0.22), rgba(14,95,181,0.06) 45%, rgba(0,0,0,0) 72%)',
        }}
      />

      {/* fixed particle canvas (z-0) — hidden in static mode */}
      {!isStatic && (
        <canvas
          ref={canvasRef}
          className="pointer-events-none fixed inset-0 z-0 h-screen w-screen"
          style={{ transition: 'opacity 0.2s linear' }}
        />
      )}

      {/* ---------------- HERO ---------------- */}
      <section
        id="hero"
        ref={heroRef}
        className="relative z-10 flex min-h-screen items-center"
      >
        {isStatic && (
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0"
            style={{ background: 'radial-gradient(70% 60% at 70% 45%, rgba(43,194,216,0.28), rgba(14,95,181,0.05) 50%, rgba(0,0,0,0) 75%)' }}
          />
        )}
        <div ref={heroInner} className="relative mx-auto w-full max-w-[1240px] px-6 md:px-10">
          <div className="max-w-[640px]">
            <p className="mb-6 text-[12px] font-semibold uppercase tracking-[0.28em]" style={{ color: 'var(--particle)' }}>
              Agents · Automations · AI Skills
            </p>
            <h1 className="text-[clamp(2.4rem,5.6vw,4.6rem)] font-extrabold leading-[1.04] tracking-[-0.02em]">
              We build <span style={{ color: 'var(--particle)' }}>AI systems</span> that run your business — so you don't have to.
            </h1>
            <p className="mt-7 max-w-[540px] text-[clamp(1rem,1.25vw,1.18rem)] leading-relaxed" style={{ color: 'var(--text2)' }}>
              We don't just build AI tools — we build systems that run your business while you sleep. From clinics to media companies, marketing agencies to coaching firms, we help businesses stop doing things manually and start running on AI.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <a
                href="#"
                className="rounded-full px-7 py-3.5 text-[15px] font-semibold transition-transform duration-200 hover:-translate-y-0.5"
                style={{ background: 'var(--accent)', color: '#021018', boxShadow: '0 10px 40px -10px rgba(43,160,220,0.7)' }}
              >
                Book a Free Call
              </a>
              <a
                href="#solutions"
                className="rounded-full border px-7 py-3.5 text-[15px] font-semibold transition-colors duration-200 hover:bg-white/5"
                style={{ borderColor: 'rgba(246,246,253,0.18)', color: 'var(--text)' }}
              >
                Explore Solutions
              </a>
            </div>
          </div>
        </div>

        {!isStatic && (
          <div className="pointer-events-none absolute bottom-8 left-1/2 -translate-x-1/2 text-[11px] uppercase tracking-[0.3em]" style={{ color: 'var(--text2)' }}>
            Scroll
          </div>
        )}
      </section>

      {/* ---------------- SERVICES ---------------- */}
      {isStatic ? (
        // STATIC: normal stacked grid, wrapper collapses to auto height
        <section id="services" className="relative z-10 mx-auto w-full max-w-[1240px] px-6 py-24 md:px-10">
          <ServicesHeader />
          <div className="mt-12 grid gap-5 sm:grid-cols-2">
            {SERVICES.map((s, i) => (
              <ServiceCard key={i} index={i} service={s} active />
            ))}
          </div>
        </section>
      ) : (
        // ANIMATED: tall wrapper + sticky stage
        <div id="services" ref={wrapRef} style={{ height: `${SERVICES_SCROLL_VH}vh` }} className="relative z-10">
          <div className="sticky top-0 flex h-screen items-center overflow-hidden">
            <div className="mx-auto grid w-full max-w-[1240px] grid-cols-1 gap-10 px-6 md:px-10 lg:grid-cols-2">
              {/* left: header + counter + card list */}
              <div>
                <ServicesHeader />
                <div className="mt-3 mb-7 flex items-baseline gap-3">
                  <span className="text-[2.6rem] font-extrabold tabular-nums leading-none" style={{ color: 'var(--particle)' }}>
                    {String(activeStep + 1).padStart(2, '0')}
                  </span>
                  <span className="text-[1.1rem] font-medium tabular-nums" style={{ color: 'var(--text2)' }}>/ 05</span>
                </div>
                <div className="flex flex-col gap-3">
                  {SERVICES.map((s, i) => (
                    <ServiceCard key={i} index={i} service={s} active={i === activeStep} compact />
                  ))}
                </div>
              </div>
              {/* right: empty — the morphing particle cloud lives here (canvas behind) */}
              <div className="hidden lg:block" />
            </div>
          </div>
        </div>
      )}

      {/* ---------------- #solutions (normal flow, zero overlap) ---------------- */}
      <section id="solutions" className="relative z-10 mx-auto w-full max-w-[1240px] px-6 py-28 md:px-10" style={{ background: TOKENS.base }}>
        <p className="mb-5 text-[12px] font-semibold uppercase tracking-[0.28em]" style={{ color: 'var(--particle)' }}>
          Ready when you are
        </p>
        <h2 className="max-w-[820px] text-[clamp(1.9rem,3.6vw,3.1rem)] font-extrabold leading-[1.08] tracking-[-0.02em]">
          Let's map the systems that should be running your business.
        </h2>
        <div className="mt-9">
          <a
            href="#"
            className="inline-block rounded-full px-7 py-3.5 text-[15px] font-semibold transition-transform duration-200 hover:-translate-y-0.5"
            style={{ background: 'var(--accent)', color: '#021018', boxShadow: '0 10px 40px -10px rgba(43,160,220,0.7)' }}
          >
            Book a Free Call
          </a>
        </div>
      </section>
    </div>
  );
}

function ServicesHeader() {
  return (
    <div>
      <p className="text-[12px] font-semibold uppercase tracking-[0.28em]" style={{ color: 'var(--particle)' }}>
        What We Build
      </p>
      <h2 className="mt-4 text-[clamp(2rem,4vw,3.4rem)] font-extrabold leading-[1.05] tracking-[-0.02em]">
        AI Automations &amp; Skills
      </h2>
    </div>
  );
}

function ServiceCard({ index, service, active, compact }) {
  return (
    <div
      className="rounded-2xl border px-6 py-5 transition-all duration-500 ease-out"
      style={{
        background: active ? 'rgba(43,160,220,0.10)' : 'rgba(5,5,7,0.7)',
        borderColor: active ? 'var(--accent)' : 'rgba(246,246,253,0.08)',
        boxShadow: active ? '0 0 0 1px rgba(43,160,220,0.5), 0 24px 60px -28px rgba(43,160,220,0.8)' : 'none',
        opacity: active ? 1 : 0.5,
        transform: active ? 'translateX(0)' : 'translateX(0)',
      }}
    >
      <div className="flex items-start gap-4">
        <span
          className="mt-0.5 text-[13px] font-bold tabular-nums"
          style={{ color: active ? 'var(--particle)' : 'var(--text2)' }}
        >
          {String(index + 1).padStart(2, '0')}
        </span>
        <div>
          <h3 className="text-[1.15rem] font-bold tracking-[-0.01em]">{service.title}</h3>
          <p className={`mt-1.5 text-[0.92rem] leading-relaxed ${compact ? '' : ''}`} style={{ color: 'var(--text2)' }}>
            {service.desc}
          </p>
        </div>
      </div>
    </div>
  );
}

window.AIBuddiesHero = AIBuddiesHero;

/* ============================================================================
   PORTING NOTE (Next.js App Router + R3F project)
   1. Add  "use client";  as the very first line, and replace the
      `const THREE = window.THREE;` line with  import * as THREE from 'three';
   2. This REPLACES src/components/three/particle-field.tsx — delete that R3F
      version; do not keep both (this file owns the particle field now).
   3. Hero + Services render under section ids #hero and #services, with
      #solutions following in NORMAL document flow (no pinning) below them.
   4. The fixed canvas is z-0; all page content sits at z-10 above it.
   ========================================================================== */
